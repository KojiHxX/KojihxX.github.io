<img src="https://orteil.dashnet.org/legacy/img/logo.png"></img>

# neverending-legacy
Ported version of Orteil's [Neverending Legacy](https://orteil.dashnet.org/legacy/), so I could play it at school lole

This port is for my pleasure, you should try the regular game out on the regular website. [https://orteil.dashnet.org/legacy/](https://orteil.dashnet.org/legacy/)

# play it now
[https://xMinota.github.io/neverending-legacy](https://xMinota.github.io/neverending-legacy)

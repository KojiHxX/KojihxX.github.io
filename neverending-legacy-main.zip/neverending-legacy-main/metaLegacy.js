Meta=function()
{
	//keep this updated with each new release and fork
	//.version should match the version's G.engineVersion in main.js
	var versions=[
		{name:'Legacy v1',version:1,url:'/'},
	];
	
	G.versions=versions;
}